# Top 5 L2 Categories (Subcategories)

Based on analysis of 1,000 classified issues:

## 🥇 1. L2.1.1 - Context Management
- **Count:** 163 issues (16.3%)
- **L1 Parent:** Core Functionality
- **Description:** Issues with context window usage, compaction, token limits
- **Common patterns:** "Context compaction fails", "Token limit errors", "Context overflow"

## 🥈 2. L2.1.2 - Session Management  
- **Count:** 94 issues (9.4%)
- **L1 Parent:** Core Functionality
- **Description:** Session lifecycle, persistence, state management
- **Common patterns:** "Session won't resume", "Lost conversation history", "Session crashes"

## 🥉 3. L2.4.1 - File Operations
- **Count:** 81 issues (8.1%)
- **L1 Parent:** Tools & Execution
- **Description:** File read/write, edit operations, file system access
- **Common patterns:** "Edit tool fails", "File not saved", "Cannot read file"

## 4. L2.1.3 - Agent Behavior
- **Count:** 41 issues (4.1%)
- **L1 Parent:** Core Functionality
- **Description:** Agentic loop, autonomous execution, task completion
- **Common patterns:** "Agent gets stuck in loop", "Task doesn't complete"

## 5. L2.3.1 - Rendering & Display
- **Count:** 40 issues (4.0%)
- **L1 Parent:** Terminal UI
- **Description:** Visual layout, rendering bugs, display issues
- **Common patterns:** "Text overlaps", "Colors wrong", "Progress bar doesn't update"

---

## Key Insights

1. **Context Management dominates** (16.3%) - This is THE biggest pain point
   - Nearly 1 in 6 issues relate to context/token management
   - Suggests need for better context handling UX

2. **Core Functionality issues cluster** - Top 2 L2s (25.7%) are under L1.1
   - Context + Session = fundamental product challenges
   - Should be priority for stability improvements

3. **File Operations** (8.1%) - 3rd highest
   - Critical for developer workflow
   - Edit tool and file handling need attention

4. **"Other" is high** (35.7% of all issues)
   - 357 issues don't fit existing L2 subcategories
   - Indicates taxonomy gaps
   - Recommend reviewing these for new L2 patterns

---

## Recommendations

### Immediate Actions
1. **Deep dive on Context Management** (163 issues)
   - What specific failures are most common?
   - Can UX improvements reduce confusion?
   - Are there technical fixes needed?

2. **Review "Other" L2 tags** (357 issues)
   - Identify top 5 recurring patterns
   - Consider adding new L2 subcategories
   - Could reduce "Other" from 35.7% to <10%

### Strategic Focus
- **Core Functionality** (L1.1) represents 40.5% of issues
  - Within that, Context (16.3%) + Session (9.4%) = 25.7%
  - These two L2s alone are 1/4 of entire backlog
  - Warrants dedicated sprint or working group

---

Generated from: 1,000 classified GitHub issues
Date: December 2025
